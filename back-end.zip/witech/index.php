<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="style.css">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script>

    <title>AshFit | Home</title>

  </head>
  <body>
    <header>
      <div class="container">
        <div id="branding">
          <h1><img src="ash_logo.png"></h1>
        </div>
        <nav>
          <ul class="nav justify-content-end">
            <li class="nav-item">
              <a class="nav-link active" href="index.php">Home</a>
            </li>
            <li class="nav-item">
              <a class="nav-link active" href="#module">Modules</a>
            </li>
            <li class="nav-item">
              <a class="nav-link active" href="#track">Track Progress</a>
            </li>
            <li  class="nav-item">
              <a  class="nav-link" href="#team">Team</a>
            </li>
            <a href="view/login.php"><button class="btn btn-dark">GET STARTED</button></a> 
          
          </ul>
        </nav>
      </div>

    </header>
  

    <section id="showcase">
      <div class="bd-example">
        <div id="carouselExampleCaptions" class="carousel slide" data-ride="carousel">
          <ol class="carousel-indicators">
            <li data-target="#carouselExampleCaptions" data-slide-to="0" class="active"></li>
            <li data-target="#carouselExampleCaptions" data-slide-to="1"></li>
            <li data-target="#carouselExampleCaptions" data-slide-to="2"></li>
          </ol>
          <div class="carousel-inner">
            <div  class="carousel-item active">
              <img src="hero_bg_2.jpg" class="d-block w-100" alt="..." id="parallax2">
              <div class="carousel-caption d-none d-md-block">
                <h5>Let's Help You Reach Your Fitness Goals !!!</h5>
                <p>Take the opportunity this semester to get fit with AshFit.</p>
              </div>
            </div>
            <div class="carousel-item" >
              <img src="hero_b1_1.jpg" class="d-block w-100" alt="..." id="parallax2">
              <div class="carousel-caption d-none d-md-block">
                <h5>Your Friendly Neighbourhood Gym Buddy</h5>
                <p>Track your progress as you improve your health this semester.</p>
              </div>
            </div>
            <div class="carousel-item" >
              <img src="gym5.jpg" class="d-block w-100" alt="..." id="parallax2">
              <div class="carousel-caption d-none d-md-block">
                <h5>Less Pain, More Gain with AshFit !!!</h5>
                <p>You need not stress about monitoring your progress with us.</p>
              </div>
            </div>
          </div>
          <a class="carousel-control-prev" href="#carouselExampleCaptions" role="button" data-slide="prev">
            <span class="carousel-control-prev-icon" aria-hidden="true"></span>
            <span class="sr-only">Previous</span>
          </a>
          <a class="carousel-control-next" href="#carouselExampleCaptions" role="button" data-slide="next">
            <span class="carousel-control-next-icon" aria-hidden="true"></span>
            <span class="sr-only">Next</span>
          </a>
        </div>
      </div>
    
    </section>

    <section id="module">
      <div class="container">
        <h6>FEATURED MODULES:</h6>
        <div class="card-deck">
          <div class="card">
            <img src="gym1.jpg" class="card-img-top" alt="...">
            <div class="card-body">
              <h5 class="card-title">Weight Loss</h5>
              <p class="card-text">This is a longer card with supporting text below as a natural lead-in to additional content. This content is a little bit longer.</p>
              <a href="view/login.php" class="btn btn-dark">Get Started</a>
            </div>
          </div>
          <div class="card">
            <img src="img_4.jpg" class="card-img-top" alt="...">
            <div class="card-body">
              <h5 class="card-title">Muscle Building</h5>
              <p class="card-text">This card has supporting text below as a natural lead-in to additional content.</p>
              <a href="view/login.php" class="btn btn-dark">Get Started</a>
            </div>
          </div>
          <div class="card">
            <img src="img_5.jpg" class="card-img-top" alt="...">
            <div class="card-body">
              <h5 class="card-title">Enhance Strength</h5>
              <p class="card-text">This is a wider card with supporting text below as a natural lead-in to additional.</p>
              <a href="view/login.php" class="btn btn-dark">Get Started</a>
            </div>
          </div>
        </div>

      </div>
    </section>

    <div>
      <div id="parallax"></div>
    </div>

    <section id="track">
      <div class="container">
        <h6>TRACK YOUR PROGRESS</h6>
        <div class="card-deck">
          <div class="card">
            <img src="gym10.jpg" class="card-img-top" alt="...">
            <div class="card-body">
              <h5 class="card-title">Watch Your Weight</h5>
              <p class="card-text">This is a longer card with supporting text below as a natural lead-in to additional content. This content is a little bit longer.</p>
              <a href="view/login.php" class="btn btn-dark">Get Started</a>
            </div>
          </div>
          <div class="card">
            <img src="gym11.png" class="card-img-top" alt="...">
            <div class="card-body">
              <h5 class="card-title">Manage Your Goals</h5>
              <p class="card-text">This card has supporting text below as a natural lead-in to additional content.</p>
              <a href="view/login.php" class="btn btn-dark">Get Started</a>
            </div>
          </div>
          <div class="card">
            <img src="gym12.jpg" class="card-img-top" alt="...">
            <div class="card-body">
              <h5 class="card-title">Check Your Diet</h5>
              <p class="card-text">This is a wider card with supporting text below as a natural lead-in to additional content. This card has even longer content than the first to show that equal height action.</p>
              <a href="view/login.php" class="btn btn-dark"s>Get Started</a>
            </div>
          </div>
        </div>
      </div>
    </section>


    <section>
      <div>
        <div id="parallax">
          <h2 id="header">Team</h2>    
        </div>
      </div>
    </section>

    <section id="team">
      <div class="container">
        <h6> TEAM </h6>
        <div class="card-columns">
          <div class="card">
            <img src="person1.jpg" class="card-img-top" alt="...">
            <div class="card-body">
              <h3 class="card-title">Marian-Bernice Haligah</h3>
              <h5>Project Manager</h5>
              <p class="card-text">A confident, enthusiastic and highly organized student of Ashesi University, in her third year studying Management In Information Systems. As the project manager of WiTech, Marian-Bernice has the overall responsibility for the successful initiation, planning, design, execution of the AshFit App. <br>
              Email me: marian.haligah@ashesi.edu.gh</p>
            </div>
          </div>
          <div class="card">
            <img src="edem.jpg" class="card-img-top" alt="...">
            <div class="card-body">
              <h3 class="card-title">Edem Yegbe</h3>
              <h5>Front-End Developer</h5>
              <p class="card-text">A third-year student of Ashesi University studying Management in Information Systems. As the front-end developer of WiTech, Edem is responsible for implementing visual elements that fitness enthusiasts see and interact with, using HTML, CSS and JavaScript.<br>
              Email me: edem.yegbe@ashesi.edu.gh</p>
            </div>
          </div>
          <div class="card">
            <div class="card-body">
              <img src="sherry.jpg" class="card-img-top" alt="...">
              <h3 class="card-title">Sherifatu Zakaria</h3>
              <h5>Database Administrator</h5>
              <p class="card-text">A third-year student studying Management in Information Systems at Ashesi University. As the Database Administrator, Sherifatu is responsible for creating and administering the database component of WiTech that is non-flawed. <br>
              Email me: sherifatu.zakaria@ashesi.edu.gh</p>
            </div>
          </div>
          <div class="card">
            <div class="card-body">
              <img src="emeka.jpg" class="card-img-top" alt="...">
              <h3 class="card-title">Emeka Okwechukwu</h3>
              <h5>Back-End Developer</h5>
              <p class="card-text">A third-year computer science undergraduate in Ashesi University. As the back-end developer, Emeka deals with all matters relating to the server-side and focuses on how the web application works and interacts between the database and browser <br>
              Email: emeka.okechukwu@ashesi.edu.gh</p>
            </div>
          </div>
        </div>
      </div>
    </section>

    <section>
      
    </section>
    <footer class="footer">
      <div class="footer-content">
        <div class="footer-section about">
          <h1 class="logo=text"><span>AshFit</span> Fitness Tracker</h1>
          <p>AshFit provides the tools and resources needed to keep track of body statistics, create weekly routines, resting timer, monitor nutritional intake and find exercises that work with the equipment available in the Ashesi gym.</p>
          <span><i class="fa fa-phone"></i> &nbsp; 020-712-0551</span>
          <span><i class="fa fa-envelope"></i> &nbsp; info@ashfit.com</span><br>
          
          <a href="" class="fa fa-facebook"></a>
          <a href="" class="fa fa-instagram"></a>
          <a href="" class="fa fa-twitter"></a>
          <a href="" class="fa fa-youtube"></a>
        </div>
        <div class="footer-section links">
          <h2>Quick Links</h2>
          <br>
          <ul>
            <a href="#module"><li>Modules</li></a>
            <a href="#track"><li>Track Progress</li></a>
            <a href="#team"><li>Team</li></a>
            <a href="login.php"><li>Get Started</li></a>
          </ul>
        </div>
        <div class="footer-section contact-form">
          <h2>Contact Us</h2><br>
          <form action="index.php" method="post">
            <input type="email" name="email" class="text-input contact-input" placeholder="Your email address..."><br>
            <textarea name="message" class="text-inputc contact-input" placeholder="Your message..."></textarea><br>
            <button type="submit" class="btn btn-success contact-btn" >
                   
              Send
            </button>
          </form>
         
        </div>
      </div>
      <div class="footer-bottom">AshFit Fitness Tracker &copy; 2019 | Designed by WiTech.</div>
    </footer>
  </body>
</html>