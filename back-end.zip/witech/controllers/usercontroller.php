<?php
//call on the person class
require('../classes/userclass.php');

//controller function to add
function adduserctrl($id, $email, $password, $initialweight, $initialheight, $dateofbirth, $trn_date){
	//create a new instance of the class
	$insertp = new person_class;

	//run the insert method
	$checkinsert = $insertp->adduser_mthd($id, $email, $password, $initialweight, $initialheight, $dateofbirth, $trn_date);

	if ($checkinsert) {
		return $checkinsert;
	}else{
		return false;
	}

	//return result
}

//controller function to login
function viewuserctrl($id, $password){
	//create a new instance of the class
	$insertp = new person_class;

	//run the insert method
	$checkinsert = $insertp->viewuser_mthd($id, $password);

	if ($checkinsert) {
		return $checkinsert;
	}else{
		return false;
	}

	//return result
}

?>