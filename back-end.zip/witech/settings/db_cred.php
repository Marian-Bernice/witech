<?php
//Database credentials
define("DATABASE", "webtech_fall2019_marian_haligah");
define("SERVER", "localhost");
define("USERNAME", "marian_haligah");
define("PASSWD", "marian_haligah");

?>