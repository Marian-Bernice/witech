Important Note:


Change your database username and password in db.php file.


Create Database Using the following Query:

DROP SCHEMA IF EXISTS witech;
CREATE DATABASE witech;
USE witech;


and Create Table either importing attached sql file (W2021.sql)
