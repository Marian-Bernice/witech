<?php

require('db.php');
include("auth.php");
$id=$_REQUEST['id'];
$query = "SELECT * from progress where id='".$id."'"; 
$result = mysqli_query($con, $query) or die ( mysqli_error());
$row = mysqli_fetch_assoc($result);
?>

<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<title>Update Entry</title>
<link rel="stylesheet" href="css/style.css" />
</head>
<body>
<div class="form">
<h1>Update Entry</h1>
<?php
$status = "";
if(isset($_POST['new']) && $_POST['new']==1)
{
$id=$_REQUEST['id'];
$date = date("Y-m-d H:i:s");
$weight =$_REQUEST['weight'];
$time =$_REQUEST['time'];
$submittedby = $_SESSION["id"];
$update="update progress set date='".$date."', weight='".$weight."', time='".$time."', submittedby='".$submittedby."' where id='".$id."'";
mysqli_query($con, $update) or die(mysqli_error());
$status = "The update was successful. </br></br><a href='report.php'>View updated progress</a>";
echo '<p style="color:#FF0000;">'.$status.'</p>';
}else {
?>
<div>
<form name="form" method="post" action=""> 
<input type="hidden" name="new" value="1" />
<input name="id" type="hidden" value="<?php echo $row['id'];?>" />
<p><input type="text" pattern="\d+" name="weight" placeholder="Enter weight" required value="<?php echo $row['weight'];?>" /></p>
<p><input type="text" pattern="\d+" name="time" placeholder="Enter time in seconds" required value="<?php echo $row['time'];?>" /></p>
<p><input type="text" name="date" placeholder="Enter date" required value="<?php echo $row['date'];?>" /></p>
<p><input name="submit" type="submit" value="Update" /></p>
</form>
<?php } ?>
</div>
    </div>
    </div>
  </body>
</html>