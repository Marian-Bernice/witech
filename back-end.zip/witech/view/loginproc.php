
<!doctype html>
<html lang="en">
<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="../style2.css">
    <link rel="stylesheet" href="../style.css">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script>

    <title>Registeration Successful</title>

</head>

<body>
	<?php
	//include the controller
	require('../controllers/usercontroller.php');

	session_start();

	//check if submit button was click
	if (isset($_GET['uview'])) {
		//grab form data and store in variable
		$id = $_GET['id'];
		$password = $_GET['password'];

		//call function to add
		$ret =  viewuserctrl($id, $password);
		//echo result
		if ($ret) {
			$_SESSION['id'] = $id;
			header("Location: ../dashboard.php");
		} else{
			echo "<div class='form'><h3>Registration Failed: Please check your details again.</h3><br/>Click here to try again <a href='adduser.php'>Register Again</a></div>";
		}
	}

	?>
</body>
</html>