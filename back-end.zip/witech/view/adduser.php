<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="../style2.css">
    <link rel="stylesheet" href="../style.css">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script>

    <script type="text/javascript" src="../validate.js"></script>

    <title>AshFit | Sign Up</title>

  </head>

  <body>
    <header>
      <div class="container">
        <div id="branding">
          <h1><img src="../ash_logo.png"></h1>
        </div>
        <nav>
          <ul class="nav justify-content-end">
            <li class="nav-item">
              <a class="nav-link active" href="../index.php">Home</a>
            </li>
            
            
          </ul>
        </nav>
      </div>

      <div class="overall">
        <div class="signup-page">
          <div class="form">       
            <form name="registration" action="adduserproc.php" method="">
              <input type="text" name="id" minlength="8" maxlength="8" placeholder="Personal ID" required />
              <input type="email" pattern="^[a-z]+[\-.]*[a-z]+@ashesi\.edu\.gh$" name="email" placeholder="Ashesi Email" required />
              <input type="password" name="password" placeholder="Password" required />
              <input type="text" pattern="\d+" name="initialweight" placeholder="Current Weight (KG)" required />
              <input type="text" pattern="\d+" name="initialheight" placeholder="Current Height (CM)" required />
              <input type="text" pattern="^([0-2][0-9]|(3)[0-1])(\/)(((0)[0-9])|((1)[0-2]))(\/)\d{4}$" minlength="10" maxlength="10" name="dateofbirth" placeholder="Date of Birth (DD/MM/YYYY)" required />
              <button type="submit" name="uadd">Sign Up</button>
              <p class="message">Already Signed Up?...<a href="login.php">Login</a></p>
              </form>
          </div>
        </div>
      </div>
    </header>

    <footer class="footer">
      <div class="footer-content">
        <div class="footer-section about">
          <h1 class="logo=text"><span>AshFit</span> Fitness Tracker</h1>
          <p>AshFit provides the tools and resources needed to keep track of body statistics, create weekly routines, resting timer, monitor nutritional intake and find exercises that work with the equipment available in the Ashesi gym.</p>
          <span><i class="fa fa-phone"></i> &nbsp; 020-712-0551</span>
          <span><i class="fa fa-envelope"></i> &nbsp; info@ashfit.com</span><br>
          
          <a href="" class="fa fa-facebook"></a>
          <a href="" class="fa fa-instagram"></a>
          <a href="" class="fa fa-twitter"></a>
          <a href="" class="fa fa-youtube"></a>
        </div>
        <div class="footer-section links">
          <h2>Quick Links</h2>
          <br>
          <ul>
            <a href="../index.php"><li>Modules</li></a>
            <a href="../index.php"><li>Track Progress</li></a>
            <a href="../index.php"><li>Team</li></a>
            <a href="../login.php"><li>Get Started</li></a>
          </ul>
        </div>
        <div class="footer-section contact-form">
          <h2>Contact Us</h2><br>
          <form action="../index.php" method="post">
            <input type="email" name="email" class="text-input contact-input" placeholder="Your email address..."><br>
            <textarea name="message" class="text-input contact-input" placeholder="Your message..."></textarea><br>
            <button type="submit" class="btn btn-success contact-btn" >
                   
              Send
            </button>
          </form>
         
        </div>
      </div>
      <div class="footer-bottom">AshFit Fitness Tracker &copy; 2019 | Designed by WiTech.</div>
    </footer>
  </body>
</html>
