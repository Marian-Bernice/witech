
<!doctype html>
<html lang="en">
<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="../style2.css">
    <link rel="stylesheet" href="../style.css">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script>

    <title>Registeration Successful</title>

</head>

<body>
	<?php
	//include the controller
	require('../controllers/usercontroller.php');

	//check if submit button was click
	if (isset($_GET['uadd'])) {
		//grab form data and store in variable
		$id = $_GET['id'];
		$email = $_GET['email'];
		$password = $_GET['password'];
		$initialweight = $_GET['initialweight'];
		$initialheight = $_GET['initialheight'];
		$dateofbirth = $_GET['dateofbirth'];
		$trn_date = date("Y-m-d H:i:s");

		//call function to add
		$ret =  adduserctrl($id, $email, $password, $initialweight, $initialheight, $dateofbirth, $trn_date);
		//echo result
		if ($ret) {
			echo "<div class='form'><h3>You are registered successfully.</h3><br/>Click here to <a href='login.php'>Login</a></div>";
		} else{
			echo "<div class='form'><h3>Registration Failed: Please check your details again.</h3><br/>Click here to try again <a href='adduser.php'>Register Again</a></div>";
		}
	}

	?>
</body>
</html>