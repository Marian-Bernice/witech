<?php
//fetch from the progress table
require('db.php');
include("auth.php");
$output = '';
if(isset($_POST["query"]))
{
 $search = mysqli_real_escape_string($con, $_POST["query"]);
 $query = "
  SELECT * FROM progress 
  WHERE module LIKE '%".$search."%'
  OR date LIKE '%".$search."%' 
  OR weight LIKE '%".$search."%' 
  OR time LIKE '%".$search."%' 
 ";
}
else
{
 $query = "
  SELECT * FROM progress ORDER BY id
 ";
}
$result = mysqli_query($con, $query);
if(mysqli_num_rows($result) > 0)
{
 $output .= '
  <div class="table-responsive">
   <table class="table table bordered">
    <tr>
     <th>Module</th>
     <th>Date</th>
     <th>Weight</th>
     <th>Time (minutes)</th>
     <th></th>
     <th></th>
    </tr>
 ';
 while($row = mysqli_fetch_array($result))
 {
  $output .= '
   <tr>
    <td>'.$row["module"].'</td>
    <td>'.$row["date"].'</td>
    <td>'.$row["weight"].'</td>
    <td>'.$row["time"].'</td>
    <td align="center">
    <a href="edit.php?id='.$row["id"].';">Edit</a>
    </td>
    <td align="center">
    <a href="delete.php?id='.$row["id"].';">Delete</a>
    </td>
   </tr>
  ';
 }
 echo $output;
}
else
{
 echo 'There are no previous workouts found under your criteria :(';
}

?>