<?php

require('db.php');
include("auth.php");
$id=$_REQUEST['id'];
$query = "SELECT * from users where id='".$id."'"; 
$result = mysqli_query($con, $query) or die ( mysqli_error());
$row = mysqli_fetch_assoc($result);
?>

<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<title>Update Your Profile</title>
<link rel="stylesheet" href="css/style.css" />
</head>
<body>
<div class="form">
<h1>Update Entry</h1>
<?php
$status = "";
if(isset($_POST['new']) && $_POST['new']==1)
{
$email =$_REQUEST['email'];
$initialweight =$_REQUEST['initialweight'];
$initialheight =$_REQUEST['initialheight'];
$dateofbirth =$_REQUEST['dateofbirth'];
$id = $_SESSION["id"];
$update="update users set email='".$email."', initialweight='".$initialweight."', initialheight='".$initialheight."', dateofbirth='".$dateofbirth."' where id='".$id."'";
mysqli_query($con, $update) or die(mysqli_error());
$status = "The update was successful. </br></br><a href='profile.php'>View updated progress</a>";
echo '<p style="color:#FF0000;">'.$status.'</p>';
}else {
?>
<div>
<form name="form" method="post" action=""> 
<input type="hidden" name="new" value="1" />
<input name="id" type="hidden" value="<?php echo $row['id'];?>" />
<p><input type="email" pattern="^[a-z]+[\-.]*[a-z]+@ashesi\.edu\.gh$" name="email" placeholder="Enter new email" required value="<?php echo $row['email'];?>" /></p>
<p><input type="text" pattern="\d+" name="initialweight" placeholder="Enter new weight" required value="<?php echo $row['initialweight'];?>" /></p>
<p><input type="text" pattern="\d+" name="initialheight" placeholder="Enter new height" required value="<?php echo $row['initialheight'];?>" /></p>
<p><input type="text" pattern="^([0-2][0-9]|(3)[0-1])(\/)(((0)[0-9])|((1)[0-2]))(\/)\d{4}$" name="dateofbirth" placeholder="Enter date of birth" required value="<?php echo $row['dateofbirth'];?>" /></p>
<p><input name="submit" type="submit" value="Update" /></p>
</form>
<?php } ?>
</div>
    </div>
    </div>
  </body>
</html>