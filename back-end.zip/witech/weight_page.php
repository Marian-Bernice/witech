<?php

require('db.php');
include("auth.php");

$status = "";
if(isset($_POST['new']) && $_POST['new']==1)
{
$module = 'Weight Loss';
$date = date("Y-m-d H:i:s");
$weight =$_REQUEST['weight'];
$time = $_REQUEST['time'];
$submittedby = $_SESSION["id"];
$ins_query="insert into progress (`module`,`date`,`weight`,`time`,`submittedby`) values ('$module','$date','$weight','$time','$submittedby')";
mysqli_query($con,$ins_query) or die(mysql_error());
$status = "Today's weight been added successfully.";
}
?>

<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="style.css">
    <link rel="stylesheet" href="style2.css">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
    <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script>

    <script type="text/javascript" src="validate.js"></script>

    <title>AshFit | Modules</title>

     <style>
      * {
        box-sizing: border-box;
      }
      
      /* Create two equal columns that floats next to each other */
      .column {
        float: left;
        width: 50%;
        padding: 10px;
      }
      
      /* Clear floats after the columns */
      .row:after {
        content: "";
        display: table;
        clear: both;
      }
      </style>

  </head>
  <body>
    <header>
      <div class="container">
        <div id="branding">
          <h1><img src="ash_logo.png"></h1>
        </div>
        <nav>
          <ul class="nav justify-content-end">
          <li class="nav-item">
              <a class="nav-link active" href="dashboard.php">Home</a>
            </li>
            <li class="nav-item">
              <a class="nav-link active" href="profile.php">Profile</a>
            </li>
            <li class="nav-item">
              <a class="nav-link active" href="dashboard.php#track">Track Progress</a>
            </li>
            <li class="nav-item">
              <a class="nav-link active" href="dashboard.php#support">Support</a>
            </li>
            </li>
            <li  class="nav-item">
              <a  class="nav-link" href="dashboard.php#team">Team</a>
            </li>
            <a href="logout.php"><button class="btn btn-dark">LOG OUT</button></a>            
          </ul>
        </nav>
      </div>

    </header>

    <section>
    <div class="row" style="margin: auto">
      <div class="column">
        <div class="col-lg-4">
            <div class="fixtures">
              <h3>Workout Routine</h3>
              <img src="gain3.png">
            </div>
        </div>
      </div>
      <div class="column">
        <div class="col-lg-4">
            <div class="fixtures">
                <div class="overall">
                    <div class="signup-page">
                      <div class="form">

                        <form name="form" method="post" action=""> 
                        <input type="hidden" name="new" value="1" />
                        <input type="text" pattern="\d+" name="weight" placeholder="What's today's weight in KG?" required />
                        <input type="text" pattern="\d+" name="time" placeholder="How long was the workout in minutes?" required />
                        <button name="submit" type="submit">Update</button> 
                        </form>
                        <a href="https://fitlb.com/tabata-timer" target="_blank"><button>Set Timer</button></a>
                        <a href="report.php" target="_blank"><button>Get Progess Report</button></a>
                        <br></br> 
                        <p style="color:#4BB543; font-size:15px"><?php echo $status; ?></p>
                      </div>

                      <script src="https://code.jquery.com/jquery-3.4.1.min.js"></script>
            
                      <script>
                        $('.message a').click(function() {
                          $('form').animate({height:"toggle", opacity:"toggle"}, "slow");
                        });
                        
                      </script>
                    </div>
                  </div>
            </div>
        </div>
      </div>
    </div>
  </section>

    <footer class="footer">
      <div class="footer-content">
        <div class="footer-section about">
          <h1 class="logo=text"><span>AshFit</span> Fitness Tracker</h1>
          <p>AshFit provides the tools and resources needed to keep track of body statistics, create weekly routines, resting timer, monitor nutritional intake and find exercises that work with the equipment available in the Ashesi gym.</p>
          <span><i class="fa fa-phone"></i> &nbsp; 020-712-0551</span>
          <span><i class="fa fa-envelope"></i> &nbsp; info@ashfit.com</span><br>
          
          <a href="" class="fa fa-facebook"></a>
          <a href="" class="fa fa-instagram"></a>
          <a href="" class="fa fa-twitter"></a>
          <a href="" class="fa fa-youtube"></a>
        </div>
        <div class="footer-section links">
          <h2>Quick Links</h2>
          <br>
          <ul>
            <a href=""><li>Modules</li></a>
            <a href=""><li>Track Progress</li></a>
            <a href=""><li>Team</li></a>
            <a href=""><li>Testimonials</li></a>
            <a href=""><li>Get Started</li></a>
          </ul>
        </div>
        <div class="footer-section contact-form">
          <h2>Contact Us</h2><br>
          <form action="dashboard.php" method="post">
            <input type="email" name="email" class="text-input contact-input" placeholder="Your email address..."><br>
            <textarea name="message" class="text-inputc contact-input" placeholder="Your message..."></textarea><br>
            <button type="submit" class="btn btn-success contact-btn" >
                   
              Send
            </button>
          </form>
         
        </div>
      </div>
      <div class="footer-bottom">AshFit Fitness Tracker &copy; 2019 | Designed by WiTech.</div>
    </footer>
  </body>
</html>