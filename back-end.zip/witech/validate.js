$(function(){
    $("input[name=id]")[0].oninvalid = function () {
        this.setCustomValidity("This should be your 8-digit ID number. e.g. 12342019");
    };
    });
    $(function(){
        $("input[name=id]")[0].oninput= function () {
            this.setCustomValidity("");
    };
});

$(function(){
    $("input[name=email]")[0].oninvalid = function () {
        this.setCustomValidity("This should be your Ashesi email. e.g. john.doe@ashesi.edu.gh");
    };
    });
    $(function(){
        $("input[name=email]")[0].oninput= function () {
            this.setCustomValidity("");
    };
});

$(function(){
    $("input[name=initialweight]")[0].oninvalid = function () {
        this.setCustomValidity("This should only contain numbers. e.g. 80");
    };
    });
    $(function(){
        $("input[name=initialweight]")[0].oninput= function () {
            this.setCustomValidity("");
    };
});

$(function(){
    $("input[name=initialheight]")[0].oninvalid = function () {
        this.setCustomValidity("This should only contain numbers. e.g. 192");
    };
    });
    $(function(){
        $("input[name=initialheight]")[0].oninput= function () {
            this.setCustomValidity("");
    };
});

$(function(){
    $("input[name=dateofbirth]")[0].oninvalid = function () {
        this.setCustomValidity("This should be in the format DD/MM/YYYY");
    };
    });
    $(function(){
        $("input[name=dateofbirth]")[0].oninput= function () {
            this.setCustomValidity("");
    };
});



$(function(){
    $("input[name=weight]")[0].oninvalid = function () {
        this.setCustomValidity("This should only contain numbers. e.g. 80");
    };
    });
    $(function(){
        $("input[name=weight]")[0].oninput= function () {
            this.setCustomValidity("");
    };
});


$(function(){
    $("input[name=time]")[0].oninvalid = function () {
        this.setCustomValidity("This should only contain numbers. e.g. 60");
    };
    });
    $(function(){
        $("input[name=time]")[0].oninput= function () {
            this.setCustomValidity("");
    };
});