<?php

$con = mysqli_connect("localhost","marian_haligah","marian_haligah","webtech_fall2019_marian_haligah");
// Check connection
if (mysqli_connect_errno())
  {
  echo "Failed to connect to MySQL: " . mysqli_connect_error();
  }
?>