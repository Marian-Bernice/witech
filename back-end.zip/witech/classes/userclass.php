<?php
//include the database class
require('../settings/db_class.php');

/**
 * 
 */
class person_class extends db_connection
{
	//properties
	public $user_id = null;
	public $user_name = null;

	//method for insert
	public function adduser_mthd($id, $email, $password, $initialweight, $initialheight, $dateofbirth, $trn_date){
		//write the query
		$sql = "INSERT into `users`(`id`, `email`, `password`, `initialweight`, `initialheight`, `dateofbirth`, `trn_date`) 
		dVALUES('$id', '$email', '".md5($password)."', '$initialweight', '$initialheight', '$dateofbirth', '$trn_date')";

		//run the query
		return $this->db_query($sql);

	}

	//method for login
	public function viewuser_mthd($id, $password){
		//write the query
		$sql = "SELECT * FROM `users` WHERE id='$id' and password='".md5($password)."'";

		//run the query
		return $this->db_query($sql);

	}
}

?>