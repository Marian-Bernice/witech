<?php
//include the bank class file
require('userclass.php');

//include the phpunit text class
use PHPUnit\Framework\TestCase;

class UserTest extends TestCase
{
	// function to test registration
	public function testAddUser(){
        $newuser = new person_class();
		$this->assertEquals(true, $newuser->adduser_mthd('40662022', 'emeka@ashesi.edu.gh', 'Emie0001', '90', '190', '10/04/1999', '10/04/1999'));
		return $newuser;
	}

	//	function to test login
	public function testViewUser(){
    $viewuser = new person_class();
	$this->assertEquals(true, $viewuser->viewuser_mthd('40662022','Emie0001'));
	return $viewuser;
	}
	}
?>