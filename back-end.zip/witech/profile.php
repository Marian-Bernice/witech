<?php

require('db.php');
include("auth.php");

?>

<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="style.css">
    <link rel="stylesheet" href="style2.css">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
    <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script>

    <title>AshFit | Profile</title>

     <style>
      * {
        box-sizing: border-box;
      }
      
      /* Create two equal columns that floats next to each other */
      .column {
        float: left;
        width: 50%;
        padding: 10px;
      }
      
      /* Clear floats after the columns */
      .row:after {
        content: "";
        display: table;
        clear: both;
      }
      </style>

  </head>
  <body>
    <header>
      <div class="container">
        <div id="branding">
          <h1><img src="ash_logo.png"></h1>
        </div>
        <nav>
          <ul class="nav justify-content-end">
            <li class="nav-item">
              <a class="nav-link active" href="dashboard.php">Home</a>
            </li>
            <li class="nav-item">
              <a class="nav-link active" href="dashboard.php#module">Modules</a>
            </li>
            <li class="nav-item">
              <a class="nav-link active" href="dashboard.php#track">Track Progress</a>
            </li>
            <li class="nav-item">
              <a class="nav-link active" href="dashboard.php#support">Support</a>
            </li>
            </li>
            <li  class="nav-item">
              <a  class="nav-link" href="dashboard.php#team">Team</a>
            </li>
            <a href="logout.php"><button class="btn btn-dark">LOG OUT</button></a>            
          </ul>
        </nav>
      </div>

    </header>

    <section>
    <div class="fixtures">
    <font size="4">
    <table class="table table-hover">
    <?php
        $count=1;
        $id = $_SESSION["id"];
        $sel_query="Select * from users WHERE id='$id';";
        $result = mysqli_query($con,$sel_query);
        while($row = mysqli_fetch_assoc($result)) { ?>
    <tr>
        <th>Name:</th>
        <td align="center"><?php echo $row["email"]; ?></td>
    </tr>
    <tr>
        <th>Your Weight:</th>
        <td align="center"><?php echo $row["initialweight"]; ?></td>
    </tr>
    <tr>
        <th>Your Height:</th>
        <td align="center"><?php echo $row["initialheight"]; ?></td>
    </tr>
    <tr>
        <th>Date of Birth:</th>
        <td align="center"><?php echo $row["dateofbirth"]; ?></td>
    </tr>
    <tr>
        <td align="center">
        <a href="profileedit.php?id=<?php echo $row["id"]; ?>">Edit</a>
        </td> 
        <td align="center">
        <a href="profiledelete.php?id=<?php echo $row["id"]; ?>">Delete Account</a>
        </td> 
    </tr>
    
    <?php $count++; } ?>
    </table>

    </div>
    </font>
  </section>

    <footer class="footer">
      <div class="footer-content">
        <div class="footer-section about">
          <h1 class="logo=text"><span>AshFit</span> Fitness Tracker</h1>
          <p>AshFit provides the tools and resources needed to keep track of body statistics, create weekly routines, resting timer, monitor nutritional intake and find exercises that work with the equipment available in the Ashesi gym.</p>
          <span><i class="fa fa-phone"></i> &nbsp; 020-712-0551</span>
          <span><i class="fa fa-envelope"></i> &nbsp; info@ashfit.com</span><br>
          
          <a href="" class="fa fa-facebook"></a>
          <a href="" class="fa fa-instagram"></a>
          <a href="" class="fa fa-twitter"></a>
          <a href="" class="fa fa-youtube"></a>
        </div>
        <div class="footer-section links">
          <h2>Quick Links</h2>
          <br>
          <ul>
            <a href=""><li>Modules</li></a>
            <a href=""><li>Track Progress</li></a>
            <a href=""><li>Team</li></a>
            <a href=""><li>Testimonials</li></a>
            <a href=""><li>Get Started</li></a>
          </ul>
        </div>
        <div class="footer-section contact-form">
          <h2>Contact Us</h2><br>
          <form action="index.php" method="post">
            <input type="email" name="email" class="text-input contact-input" placeholder="Your email address..."><br>
            <textarea name="message" class="text-inputc contact-input" placeholder="Your message..."></textarea><br>
            <button type="submit" class="btn btn-success contact-btn" >
                   
              Send
            </button>
          </form>
         
        </div>
      </div>
      <div class="footer-bottom">AshFit Fitness Tracker &copy; 2019 | Designed by WiTech.</div>
    </footer>
  </body>
</html>