<?php
//fetch from the food table
require('db.php');
include("auth.php");
$output = '';
if(isset($_POST["query"]))
{
 $search = mysqli_real_escape_string($con, $_POST["query"]);
 $query = "
  SELECT * FROM food
  WHERE foodintake LIKE '%".$search."%'
  OR date LIKE '%".$search."%' 
 ";
}
else
{
 $query = "
  SELECT * FROM food ORDER BY id
 ";
}
$result = mysqli_query($con, $query);
if(mysqli_num_rows($result) > 0)
{
 $output .= '
  <div class="table-responsive">
   <table class="table table bordered">
    <tr>
     <th>Food</th>
     <th>Date</th>
     <th></th>
     <th></th>
    </tr>
 ';
 while($row = mysqli_fetch_array($result))
 {
  $output .= '
   <tr>
    <td>'.$row["foodintake"].'</td>
    <td>'.$row["date"].'</td>
    <td align="center">
    <a href="foodedit.php?id='.$row["id"].';">Edit</a>
    </td>
    <td align="center">
    <a href="fooddelete.php?id='.$row["id"].';">Delete</a>
    </td>
   </tr>
  ';
 }
 echo $output;
}
else
{
 echo 'There are no previous meals found under your criteria :(';
}

?>