<?php

require('db.php');
include("auth.php");
$id=$_REQUEST['id'];
$query = "SELECT * from food where id='".$id."'"; 
$result = mysqli_query($con, $query) or die ( mysqli_error());
$row = mysqli_fetch_assoc($result);
?>

<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<title>Update Your Profile</title>
<link rel="stylesheet" href="css/style.css" />
</head>
<body>
<div class="form">
<h1>Update Meal</h1>
<?php
$status = "";
if(isset($_POST['new']) && $_POST['new']==1)
{
$id=$_REQUEST['id'];
$foodintake =$_REQUEST['foodintake'];
$date = date("Y-m-d H:i:s");
$submittedby = $_SESSION["id"];
$update="update food set foodintake='".$foodintake."', date='".$date."', submittedby='".$submittedby."' where id='".$id."'";
mysqli_query($con, $update) or die(mysqli_error());
$status = "The update was successful. </br></br><a href='foodsearch.php'>View updated progress</a>";
echo '<p style="color:#FF0000;">'.$status.'</p>';
}else {
?>
<div>
<form name="form" method="post" action=""> 
<input type="hidden" name="new" value="1" />
<input name="id" type="hidden" value="<?php echo $row['id'];?>" />
<p><input type="text" name="foodintake" placeholder="Enter new height" required value="<?php echo $row['foodintake'];?>" /></p>
<p><input name="submit" type="submit" value="Update" /></p>
</form>
<?php } ?>
</div>
    </div>
    </div>
  </body>
</html>